/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET NAMES binary*/;
INSERT INTO `Address` VALUES
(90001,90001,'schoo','vatapi','lol','city','','1221','HU',0,'2026-04-20 07:47:22.917'),
(120001,1,'wdwadawd','Palócz Medla Norbert Balázs','wdwadaw','dwad','','1221','HU',0,'2026-04-20 08:06:26.940'),
(150001,150001,'asd','teszt','asd','asd','','1234','HU',0,'2026-04-21 11:43:20.956');
