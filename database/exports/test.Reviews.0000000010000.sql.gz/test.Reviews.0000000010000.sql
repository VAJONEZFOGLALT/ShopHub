/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET NAMES binary*/;
INSERT INTO `Reviews` VALUES
(120001,120001,150013,4,'Good value','Fantastic quality. Definitely recommend this to friends and family.','2026-04-20 09:39:07.409'),
(120002,3,150001,5,'Highly recommended','Great product! Fast shipping and excellent packaging.','2026-04-20 09:39:07.536'),
(120003,2,150008,5,'Best purchase ever','Perfect! Does exactly what it says it will do.','2026-04-20 09:39:07.617'),
(120004,4,150012,4,'Worth every penny','Great product! Fast shipping and excellent packaging.','2026-04-20 09:39:07.712'),
(120005,5,150007,5,'Excellent quality!','Amazing! Exceeded all my expectations. Will be ordering more.','2026-04-20 09:39:07.793'),
(120006,4,150002,4,'Exceeded expectations','Very impressed with the quality and performance of this product.','2026-04-20 09:39:07.881'),
(120007,2,150016,4,'Best purchase ever','Great product! Fast shipping and excellent packaging.','2026-04-20 09:39:07.962'),
(120008,120001,150014,5,'Exceeded expectations','This product arrived quickly and works perfectly. The quality is excellent and I will definitely buy again.','2026-04-20 09:39:08.045'),
(120009,5,150006,5,'Highly recommended','Good value for money. Works as described and arrived in perfect condition.','2026-04-20 09:39:08.132'),
(120010,3,150017,4,'Best purchase ever','Fantastic quality. Definitely recommend this to friends and family.','2026-04-20 09:39:08.215'),
(120011,2,150020,5,'Best purchase ever','Very impressed with the quality and performance of this product.','2026-04-20 09:39:08.302'),
(120012,5,150009,5,'Solid build quality','Very satisfied with this purchase. Great customer service and fast shipping.','2026-04-20 09:39:08.388'),
(120013,4,150015,5,'Good value','Fantastic quality. Definitely recommend this to friends and family.','2026-04-20 09:39:08.471'),
(120014,2,150011,4,'Amazing performance','Perfect! Does exactly what it says it will do.','2026-04-20 09:39:08.554'),
(120015,120001,150005,4,'Amazing performance','Better than expected. Highly recommend to anyone looking for quality products.','2026-04-20 09:39:08.637');
