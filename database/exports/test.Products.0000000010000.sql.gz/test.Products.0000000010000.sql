/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET NAMES binary*/;
INSERT INTO `Products` VALUES
(150001,'Vezeték nélküli fejhallgató','Prémium vezeték nélküli fejhallgató aktív zajszűrővel és 30 órás akkumulátorral','Otthon',287,23,NULL,NULL),
(150002,'USB-C kábel','Gyors USB-C kábel töltéshez és adatátvitelhez','Divat',340,32,NULL,NULL),
(150003,'Laptoptartó','Ergonomikus laptoptartó a jó testtartásért és hűtésért','Iroda',21,145,'https://res.cloudinary.com/djlcruw0i/image/upload/v1776678983/products/yq7zzndii9c7umpabeyy.png',NULL),
(150004,'Mechanikus billentyűzet','Mechanikus billentyűzet RGB világítással és egyedi billentykükkel','Otthon',159,106,NULL,NULL),
(150005,'Egérpad','Nagy egérpad csúszásmentes alappal','Iroda',295,127,NULL,NULL),
(150006,'4K webkamera','4K Ultra HD webkamera autofókusszal','Kiegészítők',100,24,NULL,NULL),
(150007,'USB hub','Többportos USB hub teljesítménytovábbítással','Kiegészítők',41,46,'https://res.cloudinary.com/djlcruw0i/image/upload/v1776678633/products/dkbklfl2trailwplyde1.png',NULL),
(150008,'Asztali lámpa','LED asztali lámpa állítható fényerővel','Sport',138,118,NULL,NULL),
(150009,'Telefontok','Védő telefontok ütésálló védelemmel','Otthon',229,133,NULL,NULL),
(150010,'Hordozható SSD','Gyors SSD 1TB tárkapacitással','Otthon',289,32,NULL,NULL),
(150011,'Monitorkar','Állítható monitorkar rögzítéssel','Elektronika',454,198,NULL,NULL),
(150012,'Kábel szervező','Kábel szervező csipeszek asztal szervezéshez','Otthon',278,35,NULL,NULL),
(150013,'Bluetooth hangszóró','Hordozható Bluetooth hangszóró vízálló kialakítással','Divat',397,62,NULL,NULL),
(150014,'Képernyővédő','Edzett üveg képernyővédő','Otthon',398,93,NULL,NULL),
(150015,'Asztalvégz szervező','Fa asztal szervező több rekesszel','Elektronika',391,48,NULL,NULL),
(150016,'Gamer szék','Gamer szék ágyéktámasszal','Otthon',496,140,NULL,NULL),
(150017,'Monitortartó','Állítható monitortartó emelő','Sport',337,51,NULL,NULL),
(150018,'Billentyűzet csuklótámasz','Csuklótámasz billentyűzet ergonómiájához','Divat',415,172,NULL,NULL),
(150019,'Kábel csipesz','Kábel csipeszek és rögzítők vezeték kezeléséhez','Iroda',455,141,NULL,NULL),
(150020,'Asztalterítő','Nagy asztalterítő egér és billentyűzet alá','Elektronika',106,162,NULL,NULL);
