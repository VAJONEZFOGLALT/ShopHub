/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET NAMES binary*/;
INSERT INTO `Users` VALUES
(1,'dwadaw','zuhnhvh@gmail.com','$2b$10$L/AA1ew/.4WIq1oRMSOV4uDGi5qAF89soR/K01QlRIBhzPg9BSX8S','ADMIN','Palócz Medla Norbert Balázs',NULL),
(2,'alice','alice@gmail.com','$2b$10$FZJ1YN3N1Qq4nJRYjRTYRu1HMtyFk8zJEFShFSwbbZx76EsYst3Q.','USER','Alice',NULL),
(3,'bob','bob@yahoo.com','$2b$10$rdKjN86EA3UbcAJE4suMK.p6NW/zUk36KV6H6jEnoyOKGCM0PJ/BK','USER','Bob',NULL),
(4,'charlie','charlie@outlook.com','$2b$10$p1C5apgGIMRp0ELx8taJU.YuGm.JJ9Qpb2t0FxiurLSZnjHawwhEm','USER','Charlie',NULL),
(5,'diana','diana@gmail.com','$2b$10$6eIdqIXsMeHYS0KVO6J7/e/h.n2D3RRX/vh/z6viVdcia1RJtu8uS','USER','Diana',NULL),
(90001,'vatapi','vatapi.2005@gmail.com','$2b$10$dAqnBqBXAxxxQUz0sR/rKeSIHFe1pcjs.yoxrtdXrURIDMgaXIlCC','ADMIN','vatapi',NULL),
(120001,'admin','admin@admin.com','$2b$10$6GYeU7ozFtUaSJJJcw/ccuyaLkyj.tugf2aJsP/arX.AvLvz2uGHG','ADMIN','Admin',NULL),
(150001,'teszt','teszt@gmail.com','$2b$10$WivednaDOsxS6IpJ9Qn9pOciQot.MukutZ8O5l.buYqAwPV1FF52u','ADMIN','',NULL);
